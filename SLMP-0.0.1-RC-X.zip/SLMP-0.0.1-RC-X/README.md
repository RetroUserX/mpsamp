# Simple Lua Multiplayer
OpenSource GTA: San Andreas Multiplayer based on Lua
## Installing client
* Download client for Windows from Releases
* Install [MoonLoader](https://www.blast.hk/moonloader) from BlastHack WebSite
* Copy & Paste all data from archive to GTA Directory
* Launch GTA: San Andreas via __slmp.exe__ file
## Installing Server
* Choose server's version: Linux / Windows
* Download archive with server from Releases
* Create new directory, Copy & Paste all data from archive there
* Open __server.cfg__ and edit every option you want
* Launch server via __start.sh__ or __start.bat__, it depends on your version
###### Server will not work without opened UDP port, don't forget to open it!
