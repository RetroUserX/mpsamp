cd modules
clear
luajit ../server.lua
read -p "Press enter to close"