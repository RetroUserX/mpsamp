# Server

## Installing on Linux

### Ubuntu/Debian/Linux Mint based

Install luajit and luarocks

```shell
$ sudo apt install luajit luarocks
```

Install dependecies from luarocks

```shell

$ luarocks install libdeflate
$ luarocks install dkjson
$ luarocks install luasocket
```
